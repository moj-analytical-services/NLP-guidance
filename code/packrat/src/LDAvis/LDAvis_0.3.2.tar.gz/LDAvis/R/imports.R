#' @importFrom digest digest
#' @importFrom parallel parLapply
#' @importFrom RJSONIO toJSON
#' @importFrom proxy dist
#' @importFrom utils packageVersion browseURL
#' @importFrom stats cmdscale
