### seal entries of proximity database
pr_DB$seal_entries()
